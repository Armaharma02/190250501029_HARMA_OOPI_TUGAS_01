/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package limas;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 *
 * @author WIN -8
 */
public class codinganlimas {
    public static void main(String[]args)throws IOException{
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        limas.prosesanlimas limas = new limas.prosesanlimas ();
        try 
        {
            System.out.println("Masukkan Nilai Luas Limas");
            String l = dataIn.readLine();
            limas.setLuas(Integer.parseInt (l));
            
            System.out.println("Masukkan Nilai Tinggi Limas");
            String b = dataIn.readLine ();
            limas.setTinggi(Integer.parseInt (b));
            
            System.out.println("Luas luas limas="+limas.getLuas());
            System.out.println("Tinggi limas="+limas.getTinggi ());
            System.out.println("Volume limas="+limas.hitungVolume ());
        }
       
        catch (IOException e)
        {
            System.out.println("Data yang di input salah");
        }
     }
    
    
}

