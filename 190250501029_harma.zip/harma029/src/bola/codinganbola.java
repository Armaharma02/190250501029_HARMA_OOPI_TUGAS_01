/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bola;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 *
 * @author WIN -8
 */
public class codinganbola {
     public static void main(String[]args)throws IOException {
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        bola.prosesanbola bola = new bola.prosesanbola ();
        try 
        {
            System.out.println("Masukkan Jarijari");
            String s = dataIn.readLine();
            bola.setJari(Integer.parseInt (s));
          
            System.out.println("Jarijari bola=");
            int jari = bola.getJari();
            System.out.println("Volume bola="+bola.hitungVolume ());
        }
            catch (IOException e)        
        {
          System.out.println("Data yang di input salah");
        }
        
    }
    
}

