/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BALOK;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author WIN -8
 */
public class codinganBALOK {
    
     public static void main(String[]args)throws IOException{
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        BALOK.prosesanBALOK BALOK = new BALOK.prosesanBALOK ();
        try   
    {
        System.out.println("inputkan Panjang");
        String p = dataIn.readLine();
        BALOK.setPanjang(Integer.parseInt (p));
        
        System.out.println("inputkan Lebar");
        String l = dataIn.readLine ();
        BALOK.setLebar(Integer.parseInt (l));
        
        System.out.println("inputkan tinggi");
        String t = dataIn.readLine ();
        BALOK.setTinggi(Integer.parseInt (t));
        
        System.out.println("Panjang BALOK="+BALOK.getPanjang());
        System.out.println("Lebar BALOK="+BALOK.getLebar ());
        System.out.println("Tinggi BALOK="+BALOK.getTinggi ());
        System.out.println("Volume BALOK="+BALOK.hitungVolume ());
        
        }
        catch (IOException e)
        {
            System.out.println("Data yang di input salah");
        }
     }
    }
