/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tabung;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 *
 * @author WIN -8
 */
public class codingantabung {
    public static void main(String[]args)throws IOException{
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        tabung.prosesantabung tabung = new tabung.prosesantabung ();
        try       
    {
        System.out.println("inputkan Jarijari");
        String r = dataIn.readLine();
        tabung.setJarijari(Integer.parseInt (r));
        
        System.out.println("inputkan tinggi");
        String t = dataIn.readLine ();
        tabung.setTinggi(Integer.parseInt (t));
        
        System.out.println("Jari jari tabung="+tabung.getJarijari());
        System.out.println("Tinggi tabung="+tabung.getTinggi ());
        System.out.println("Volume tabung="+tabung.hitungVolume ());
    }
        catch (IOException e)
    {
        System.out.println("Data yang di input salah");
        
    }
   }
}

