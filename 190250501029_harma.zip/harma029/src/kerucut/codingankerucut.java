/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kerucut;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 *
 * @author WIN -8
 */
public class codingankerucut {
    public static void main(String[]args)throws IOException{
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        kerucut.prosesankerucut kerucut = new kerucut.prosesankerucut ();
        try
        {
            System.out.println("inputkan Jarijari");
            String r = dataIn.readLine();
            kerucut.setJari(Integer.parseInt (r));
            
            System.out.println("inputkan Tinggi");
            String t = dataIn.readLine ();
            kerucut.setTinggi(Integer.parseInt (t));
            
            System.out.println("Jarijari kerucut="+kerucut.getJari());
            System.out.println("Tinggi kerucut="+kerucut.getTinggi ());
            System.out.println("Volume kerucut="+kerucut.hitungVolume ());
             
        }
        catch (IOException e)
        {
            System.out.println("Data yang di input salah");
        }
     }
    }

