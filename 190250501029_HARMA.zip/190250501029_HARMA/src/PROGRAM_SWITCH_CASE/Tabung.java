/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PROGRAM_SWITCH_CASE;

public class Tabung {
    private int Tinggi;
    private int Jari ;
    
    public void setTinggi(int tinggi)
    {
            this.Tinggi = tinggi ;
    }
    public void setJari(int jari)
    {
            this.Jari = jari ;
    }
     
    public int getTinggi()
    {
        return Tinggi;
    }
    public int getJari()
    {
        return Jari;
    }
    public double HitungLuasAlas()
    {
        double luas;
        luas = 3.14*(Jari*Jari);
        return luas;
    }
    public double Hitungvolume()
    {
        double volume;
        volume = 3.14*Jari*2*Tinggi;
        return volume;
    }
     public double HitungKeliling()
    {
        double keliling;
        keliling = 2*3.14*Jari;
        return keliling;
    }
    
    
}
